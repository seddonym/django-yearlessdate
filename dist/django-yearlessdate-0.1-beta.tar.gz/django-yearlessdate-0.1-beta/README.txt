Documentation - TODO

NB: This app is not yet ready for use.